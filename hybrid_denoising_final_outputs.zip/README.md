# Confidence-Weighted Hybrid Denoising for Mixed Gaussian and Salt-and-Pepper Noise Removal

Author: Ali Akif Köş  
Student ID: 2111041018  
Course: Digital Image Processing – Final Term Project

## Project Summary

This project evaluates a confidence-weighted hybrid image denoising pipeline for images corrupted by mixed Gaussian and salt-and-pepper impulse noise. The proposed method detects impulse-corrupted pixels, repairs them using local median statistics, applies BM3D for Gaussian noise reduction, and fuses the repaired and BM3D-denoised outputs using a spatial confidence map.

## Dataset

The experiments use the Kodak24 dataset. Images are converted to grayscale. In this notebook, `RESIZE_IMAGES=True` and `IMAGE_SIZE=(256, 256)`.

## Noise Settings

- Gaussian noise levels: [10, 25]
- Salt-and-pepper noise ratios: [5, 10, 20]%
- Main impulse detection parameter: k=2.0

## Compared Methods

- Noisy image
- Adaptive Median Filter (AMF)
- Non-Local Means (NLM)
- BM3D
- Proposed confidence-weighted hybrid method

## Evaluation Metrics

- PSNR
- SSIM
- Average runtime per image

## How to Run

1. Open the notebook in Google Colab.
2. Run all cells in order.
3. Use `RUN_MODE="quick"` for a short test or `RUN_MODE="final"` for the full experiment.
4. Results are saved under the `results/` directory.
5. The final ZIP file contains CSV tables and article-ready figures.

## Output Files

- `results/csv/per_image_results.csv`
- `results/csv/summary_results_long.csv`
- `results/csv/full_results.csv`
- `results/csv/ablation_k.csv`
- `results/csv/ablation_components.csv`
- `results/figures/*.png`

## References

- K. Dabov, A. Foi, V. Katkovnik, and K. Egiazarian, "Image denoising by sparse 3-D transform-domain collaborative filtering," IEEE Transactions on Image Processing, 2007.
- H. Hwang and R. A. Haddad, "Adaptive median filters: new algorithms and results," IEEE Transactions on Image Processing, 1995.
